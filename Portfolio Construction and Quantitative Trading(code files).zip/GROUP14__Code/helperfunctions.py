# -*- coding: utf-8 -*-
"""
Created on Wed Dec  6 13:18:08 2023

@author: vishw
"""

import yfinance as yf
import pandas as pd
import datetime
import cvxpy as cp
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


def get_mu(timeseries):
    """
    Calculates annualized mean according to Meucci's proposal for
  the projection of invariants (https://ssrn.com/abstract=1586656).
  Returns the annualized mean of the input
  timeseries: pandas DataFrame containing daily returns
"""
    
    return np.exp(np.log1p(timeseries).mean()*252)-1

def _mu(timeseries):
    """
    Local performance function; equivalent to get_mu.
    Returns the annualized mean of the input
    timeseries: pandas dataframe containing daily returns
    """
    return np.exp(np.log1p(timeseries).mean()*252)-1

def get_cov(timeseries, annualized=True):
    S = timeseries.cov()
    if annualized:
        S = S * 252
    return S

def get_std(timeseries, annualized=True):
    std = timeseries.std()
    if annualized:
        std = std * np.sqrt(252)
    return std

def get_var(timeseries, annualized=True):
    var = timeseries.var()
    if annualized:
        var = var * 252
    return var

def get_hist_VaR(timeseries, alpha=5):
    return -np.percentile(timeseries, alpha)

def get_hist_CVaR(timeseries, alpha=5):
    belowVaR = timeseries <= np.percentile(timeseries, alpha)
    return -timeseries[belowVaR].mean()

def get_weighted_returns(assets, weights):
    portfolio_rets = assets @ weights
    return portfolio_rets

def get_mvp_weights(timeseries):
    w = cp.Variable(len(timeseries.columns))
    sigma_square = cp.quad_form(w, get_cov(timeseries))
    objective = cp.Minimize(sigma_square)
    constraints = [
        cp.sum(w) == 1,
        w >= 0
    ]
    
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.OSQP,verbose=False,max_iter = 1000)
    w_mvp = w.value
    
    return w_mvp

def get_max_ret_weights(timeseries):
    w_max = np.zeros(len(timeseries.columns))
    w_max[_mu(timeseries).argmax()] = 1

    return w_max

def get_summary_with_weights(weights, timeseries, tickers, pct=True):
    """
    Returns selected summary statistics on the portfolio.
    
    Parameters:
    - weights: vector of (portfolio) weights
    - timeseries: pandas DataFrame containing daily returns
    - pct: Boolean, defaults to True. If True, displays results in percentage format.
    """
    w_opt = weights
    positive_weights = w_opt[w_opt > 0.001]
    if pct:
        d = [
            ["### Portfolio Summary ###", ""],
            ["", ""],
            ["Number of Assets:", "{:}".format(np.count_nonzero(weights.round(6) + 0.0))],
            ["Expected Annual Return:", "{:.3f}%".format((w_opt.T @ _mu(timeseries)) * 100)],
            ["Annual Volatility:", "{:.3f}%".format(np.sqrt(w_opt.T @ get_cov(timeseries) @ w_opt) * 100)],
            ["Sharpe Ratio:", (w_opt.T @ _mu(timeseries) / np.sqrt(w_opt.T @ get_cov(timeseries) @ w_opt)).round(3)],
            ["Portfolio Leverage:", get_port_leverage(weights).round(3)],
            ["1-Year 95% VaR:", "{:.3f}%".format(100 * np.sqrt(252) * get_hist_VaR(get_weighted_returns(timeseries, weights)))],
            ["1-Year 95% CVaR:", "{:.3f}%".format(100 * np.sqrt(252) * get_hist_CVaR(get_weighted_returns(timeseries, weights)))],
            ["1-Day 95% VaR:", "{:.3f}%".format(100 * get_hist_VaR(get_weighted_returns(timeseries, weights)))],
            ["1-Day 95% CVaR:", "{:.3f}%".format(100 * get_hist_CVaR(get_weighted_returns(timeseries, weights)))],
            ["", ""],
        ]

        for v in d:
            title, value = v
            print("{:<25} {:<30}".format(title, value))
            
        print("\n### Portfolio Weights for Assets with Positive Weights ###")
        for ticker, weight in zip(tickers, positive_weights):
            print("{:<10}: {:.2%}".format(ticker, weight))

def get_top_weights(number, timeseries, weights):
    """
    Returns n(umber) of the assets with the biggest weights.
    
    Parameters:
    - number: Integer value defining the number of weights to be returned
    - timeseries: pandas DataFrame containing daily returns
    - weights: vector of (portfolio) weights
    """
    for _ in range(number):
        print(timeseries.iloc[:, (-weights).argsort()[_]].name, weights[(-weights).argsort()[_]].round(5))

    
    
def get_bot_weights(number, timeseries, weights):
    """
    Returns n(umber) of the assets with the smallest weights.
    
    Parameters:
    - number: Integer value defining the number of weights to be returned
    - timeseries: pandas DataFrame containing daily returns
    - weights: vector of (portfolio) weights
    """
    number = number - 1
    for _ in range(number + 1):
        print(timeseries.iloc[:, (weights).argsort()[number - _]].name, weights[(weights).argsort()[number - _]].round(5))


def get_port_leverage(weights):
    """
    Calculates leverage measured in excess of 1
    
    Parameters:
    - weights: vector of (portfolio) weights
    """
    return np.abs(weights).sum().round(5) - 1


"""GENERATE RANDOM PORTFOLIOS"""

def gen_weights(n, long_only=True):
    """
    Returns a vector of n weights.
    
    Parameters:
    - n: Number of weights (portfolios).
    - long_only: Boolean, defaults to True. If True, generates weights for long-only portfolios.
    """
    if long_only:
        # rand for only positive values
        r = np.random.rand(n)
        return r / sum(r)
    else:
        # randn for positive and negative
        r = np.random.randn(n)
        return r / sum(r)

def random_portfolio(timeseries):
    """
    Returns mean, standard deviation and asset weights
    for a random portfolio.
    
    Parameters:
    - timeseries: pandas DataFrame containing daily returns
    """
    M = pd.DataFrame(timeseries.mean())  # Return Vector (3x1)
    w = pd.DataFrame(gen_weights(timeseries.shape[1], 0), index=['A', 'B', 'C'])  # Weight Vector (3x1)
    S = pd.DataFrame(timeseries.cov())  # CovMatrix

    mu = w.T @ M
    sigma = np.sqrt(w.T @ S @ w)

    if sigma.iloc[0, 0] > 5:  # cleaning up outliers for plotting
        return random_portfolio(timeseries)
    return mu, sigma, w

def random_portfolio_long(timeseries):
    """
    Returns mean, standard deviation and asset weights
    for a random (long-only) portfolio.
    
    Parameters:
    - timeseries: pandas DataFrame containing daily returns for 3 assets
    """
    M = pd.DataFrame(timeseries.mean())  # Return Vector (3x1)
    w = pd.DataFrame(gen_weights(timeseries.shape[1], 1), index=['A', 'B', 'C'])  # Weight Vector (3x1)
    S = pd.DataFrame(timeseries.cov())  # CovMatrix

    mu = w.T @ M
    sigma = np.sqrt(w.T @ S @ w)

    if sigma.iloc[0, 0] > 5:  # cleaning up outliers for plotting
        return random_portfolio(timeseries)
    return mu, sigma, w

"""PLOTTING RETURNS"""

def plt_returns(returns, weights, benchmark, save=False):
    """
    Plots time-series of returns in 2-dimensional
    plot with dates on the x-axis. Visualizing return variance.
    
    Parameters:
    - returns: pandas DataFrame containing daily returns
    - weights: vector of weights; has to be the same length as the number of assets
    - benchmark: pandas DataFrame containing daily returns of a benchmark
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.plot(get_weighted_returns(returns, weights),
              label='Optimized', alpha=0.5, color="blue")
    plt.plot(benchmark, label='Index', alpha=0.3, color="red")
    ax.legend()
    plt.ylabel('Return')
    ax.legend()
    plt.tight_layout()  # more space for x and y labels
    plt.grid(alpha=0.3)

    if save:
        plt.savefig('/Users/../_vola.pdf', dpi=500, format='pdf')

    plt.show()
    
    
"""PLOTTING CUMULATIVE RETURNS"""

def plt_cum_returns(returns, weights, benchmark, save=False):
    """
    Plots time-series of cumulative returns in a 2-dimensional
    plot with dates on the x-axis.
    
    Parameters:
    - returns: pandas DataFrame containing daily returns
    - weights: vector of weights; has to be the same length as the number of assets
    - benchmark: pandas DataFrame containing daily returns of a benchmark
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.plot((returns @ weights).add(1).cumprod(),
              label='Optimized', alpha=0.5, color="blue")
    plt.plot(benchmark.add(1).cumprod(),
              label='Index', alpha=0.3, color="red")

    ax.legend()
    plt.ylabel('Cumulative Return')
    plt.tight_layout()  # more space for x and y labels
    plt.grid(alpha=0.3)

    if save:
        plt.savefig('/Users/../_opt_return.pdf', dpi=500, format='pdf')

    plt.show()
    
    
"""EFFICIENT FRONTIER WITH SCATTER PLOT"""

def plt_frontier_scatter(mu_front, sigma_front, sharpe_front, assets, save=False):
    """
    Calculates and plots the efficient frontier relative
    to all assets of the portfolio.

    Parameters:
    - mu_front: array of efficient means
    - sigma_front: array of efficient standard deviations
    - sharpe_front: array of Sharpe ratios
    - assets: pandas DataFrame containing daily returns
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)

    plt.plot(sigma_front, mu_front, color='steelblue',
              linewidth=2, alpha=0.5, label='Efficient frontier')
    # Plot frontier
    plt.plot(sigma_front[np.argmax(sharpe_front)],
              mu_front[np.argmax(sharpe_front)], marker='*',
              color='steelblue', label="Maximum Sharpe portfolio",
              markersize=10)  # Highlight max Sharpe portfolio
    plt.scatter(get_std(assets), get_mu(assets), s=8, label='Assets')

    ax.legend(loc=3)
    plt.grid(alpha=0.3)
    plt.xlabel('Standard Deviation (Volatility)')
    plt.ylabel('Expected Annual Return')

    plt.tight_layout()

    if save:
        plt.savefig('/Users/../_scatter_front.pdf', dpi=500, format='pdf')
    plt.show()


"""PLOTTING CORRELATION MATRIX"""

def plot_corr(timeseries):
    """
    Plot the correlation matrix of log returns.

    Parameters:
    - timeseries: Pandas DataFrame with log returns for multiple stocks.
    """
    # Calculate the correlation matrix
    corr_matrix = timeseries.corr()

    # Set up the matplotlib figure
    plt.figure(figsize=(10, 8))

    # Create a seaborn heatmap with a color gradient
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=.5)

    # Set plot title
    plt.title('Correlation Matrix of Daily Log Returns')

    # Show the plot
    plt.show()