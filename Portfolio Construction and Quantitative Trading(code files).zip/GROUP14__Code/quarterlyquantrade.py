# -*- coding: utf-8 -*-
"""
Created on Thu Dec  7 03:12:37 2023

@author: vishw
"""
import pandas as pd
import yfinance as yf
import datetime
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
import os

# List of Dow Jones tickers
dow_tickers = [
   "MMM", "AXP", "AAPL", "BA", "CAT", "CVX", "CSCO", "KO", 
   "GS", "HD", "HON", "IBM", "INTC", "JNJ", "JPM", "MCD", "MRK", "MSFT",
   "NKE", "PG", "RTX", "TRV", "UNH", "VZ", "V", "WMT", "DIS", "CRM" 
]

# Set the date range for historical data
end_date = datetime.datetime(2023, 12, 1)
start_date = end_date - datetime.timedelta(days=10 * 365)  # 10 years

# Download historical data and store in a DataFrame
historical_data = {}

for ticker in dow_tickers:
    try:
        data = yf.download(ticker, start=start_date, end=end_date)
        # Resample the daily data to quarterly and calculate returns
        quarterly_returns = data['Adj Close'].resample('Q').ffill().pct_change()
        historical_data[ticker] = quarterly_returns
        print(f"Downloaded data for {ticker}")
    except Exception as e:
        print(f"Error downloading data for {ticker}: {e}")

# Create a DataFrame for assets log returns
df_assets = pd.DataFrame(historical_data)

# Drop NaN values from df_assets
df_assets = df_assets.dropna()

# Display the first few rows of the cleaned DataFrames
print(df_assets)

df_2017_to_2018 = df_assets['2017-12-31':'2018-12-31']  # This selects data from 2015 to the end of 2018
df_after_2018 = df_assets['2019-01-01':]


print(df_2017_to_2018)
print(df_after_2018)

def calculate_weighted_returns(original_returns_df):
    # Create an empty dataframe to store the results
    weighted_returns_df = pd.DataFrame(index=original_returns_df.index, columns=original_returns_df.columns)

    # Iterate through each day in the original dataframe
    for date in original_returns_df.index:
        # Get the returns for the current day
        daily_returns = original_returns_df.loc[date]

        # Get the top 10 stocks with the largest return
        top_10_stocks = daily_returns.nlargest(10)

        # Calculate the sum of returns for the top 10 stocks
        sum_top_10_returns = top_10_stocks.sum()

        # Calculate the weights for the top 10 stocks
        weights = top_10_stocks / sum_top_10_returns

        # Assign weights to the corresponding stocks in the new dataframe
        weighted_returns_df.loc[date, top_10_stocks.index] = weights
        
        # Add an additional column for the sum of weights
        weighted_returns_df.loc[date, 'Sum_of_Weights'] = weights.sum()


    # Fill NaN values with 0 for stocks that are not in the top 10
    weighted_returns_df = weighted_returns_df.fillna(0)

    return weighted_returns_df

def construct_portfolio(initial_capital, weighted_returns_df):
    # Initialize a dictionary to store the portfolio values for each stock
    portfolio = {stock: 0 for stock in weighted_returns_df.columns[:-1]}  # Exclude 'Sum_of_Weights' column

    # Set the initial portfolio using the weights from the first row
    for stock in portfolio:
        portfolio[stock] = initial_capital * weighted_returns_df.at[weighted_returns_df.index[0], stock]

    # Iterate through the dataframe starting from the second row
    for i in range(1, len(weighted_returns_df)):
        current_weights = weighted_returns_df.iloc[i, :-1]
        previous_weights = weighted_returns_df.iloc[i - 1, :-1]

        for stock in portfolio:
            # Calculate the difference in weights
            weight_diff = current_weights[stock] - previous_weights[stock]
        
            # Generate buy/sell signals and update the portfolio
            if weight_diff > 0:
                # Buy signal
                buy_amount = initial_capital * weight_diff
                portfolio[stock] += round(buy_amount, 2)  # Round to avoid precision issues
            elif weight_diff < 0:
                # Sell signal
                sell_amount = initial_capital * abs(weight_diff)
                if sell_amount <= portfolio[stock]:
                    portfolio[stock] -= round(sell_amount, 2)  # Round to avoid precision issues
                else:
                    portfolio[stock] = 0  # Ensure the portfolio value doesn't go negative
        
        # Ensure all portfolio values are non-negative
        for stock in portfolio:
            if portfolio[stock] < 0:
                portfolio[stock] = 0
                
                
    return portfolio


# Example usage:
# Assuming your original dataframe is named 'returns_df'
result_df = calculate_weighted_returns(df_2017_to_2018)
#print(result_df)

initial_capital = 100000

# Assuming your weighted returns dataframe is named 'result_df'
portfolio_values = construct_portfolio(initial_capital, result_df)

# Display the final portfolio values
print("Final Portfolio Values:")
for stock, value in portfolio_values.items():
    print(f"{stock}: ${value:.2f}")

# Calculate and display the total portfolio value
total_portfolio_value = sum(portfolio_values.values())
print(f"\nTotal Portfolio Value: ${total_portfolio_value:.2f}")
