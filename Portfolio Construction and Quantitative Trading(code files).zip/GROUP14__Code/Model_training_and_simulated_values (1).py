#!/usr/bin/env python
# coding: utf-8

# In[105]:


import yfinance as yf
import pandas as pd
import pandas_ta as ta
import numpy as np
from functools import reduce
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,LSTM,Bidirectional,TimeDistributed
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from keras.layers import Input, Dense, LSTM, Reshape
from keras.models import Model
import xgboost as xgb
from sklearn.metrics import mean_squared_log_error
from sklearn.metrics import explained_variance_score
from sklearn.linear_model import Ridge
import matplotlib.pyplot as plt
from pandas_market_calendars import get_calendar


# In[106]:


tickers = ["AMJ"]
start_date = "2015-01-01"
end_date = "2023-11-30"
etf_data = {}
for ticker in tickers:
    data = yf.download(ticker, start=start_date, end=end_date)
    
    etf_data[ticker] = data

    
# ETF data frames
amj_df = etf_data["AMJ"]

# drop Volume
amj_df = amj_df.drop('Volume', axis = 1)


# In[107]:


def stats_for_model(etf_data):
    '''
    Function calculates all technical indicators possible like RSI, EMA, SMA. 
    Input: 1 data frame containing ETF data 
    Output: The data frame with all calculated values for the particular ETF.
    '''
    rsi_period = 14
    # Calculate RSI
    etf_data['RSI'] = ta.rsi(etf_data['Adj Close'], length=rsi_period)    
    # Calculate overbought/oversold conditions
    etf_data['Overbought'] = (etf_data['RSI'] > 70).astype(int)
    etf_data['Oversold'] = (etf_data['RSI'] < 30).astype(int)
    
    # Calculate divergence between price and RSI
    etf_data['Price_RSI_Divergence'] = etf_data['Close'].diff() - etf_data['RSI'].diff()
    
    # Calculate rate of change of RSI
    etf_data['ROC_RSI'] = etf_data['RSI'].pct_change() * 100
    
    # Calculate RSI trend confirmation
    etf_data['RSI_Trend_Confirmation'] = (etf_data['RSI'] > etf_data['RSI'].shift(1)).astype(int)
    
    # Assuming 'Close' is the column containing closing prices
    etf_data['EMA'] = ta.ema(etf_data['Close'], length=14)  # Adjust the period as needed
    
    # Feature 1: EMA over a specific period
    # Already calculated and stored in 'EMA' column
    
    # Feature 2: Difference between current price and EMA
    etf_data['Price_EMA_Difference'] = etf_data['Close'] - etf_data['EMA']
    
    # Feature 3: Slope of EMA
    etf_data['Slope_EMA'] = ta.slope(etf_data['EMA'])
    
    # Feature 4: EMA convergence or divergence
    etf_data['EMA_Convergence'] = (etf_data['Close'] > etf_data['EMA']).astype(int)
    etf_data['EMA_Divergence'] = (etf_data['Close'] < etf_data['EMA']).astype(int)
    
    # Feature 5: Rate of change of EMA
    etf_data['ROC_EMA'] = etf_data['EMA'].pct_change() * 100
    
    # Assuming 'Close' is the column containing closing prices
    etf_data['SMA'] = ta.sma(etf_data['Close'], length=14)  # Adjust the period as needed
    
    # Feature 1: SMA over a specific period
    # Already calculated and stored in 'SMA' column
    
    # Feature 2: Difference between current price and SMA
    etf_data['Price_SMA_Difference'] = etf_data['Close'] - etf_data['SMA']
    
    # Feature 3: Slope of SMA
    etf_data['Slope_SMA'] = ta.slope(etf_data['SMA'])
    
    # Feature 4: SMA convergence or divergence
    etf_data['SMA_Convergence'] = (etf_data['Close'] > etf_data['SMA']).astype(int)
    etf_data['SMA_Divergence'] = (etf_data['Close'] < etf_data['SMA']).astype(int)
    
    # Feature 5: Rate of change of SMA
    etf_data['ROC_SMA'] = etf_data['SMA'].pct_change() * 100
    
    dmi = ta.adx(etf_data.High, etf_data.Low, etf_data.Close)
    etf_data['ADX']=dmi['ADX_14']
    etf_data['DMI+']=dmi['DMP_14']
    etf_data['DMI-']=dmi['DMN_14']
    # Calculate ADX trend strength
    etf_data['ADX_Trend_Strength'] = etf_data['ADX'].rolling(window=3).mean()  # Adjust the rolling window parameter
    
    # Calculate DI convergence or divergence
    etf_data['DI_Convergence_Divergence'] = etf_data['DMI+'] - etf_data['DMI-']  # Adjust the length parameter
    return etf_data


# In[108]:


amj_df_stats = stats_for_model(amj_df)


# In[109]:


def data_preparation_for_dbn(stock_data):
    '''
    The function prepares data for the models defined below. 
    This function manipulates the data so that the model inputs previous day's data to predict return for current day.
    Input: Data frame with all features required for regression.
    Output: Manipulated Data frame
    '''
    new_df = pd.DataFrame()
    new_df = stock_data.shift(1)
    new_df = new_df.dropna()
    new_df = pd.merge(stock_data['Adj Close'], new_df, on = 'Date', how='inner')
    new_df = new_df.rename(columns={'Adj Close_x': 'Curr Adj Close', 'Adj Close_y': 'Prev Adj Close'})
    
    return new_df


# In[110]:


# Function Call for data preparation
amj_manipulated_data = data_preparation_for_dbn(amj_df_stats)


# In[111]:


def data_transformation(data):
    '''
    This function splits the data for model-1 into test and train part.
    '''
    X = data.drop('Curr Adj Close', axis =1)
    y = data['Curr Adj Close']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size = 0.2, random_state = 42)
    
    return X, y, X_train, X_test, y_train, y_test


# In[112]:


def smape(y_test, y_pred):
    '''
    This function calculates smape stats.
    '''
    return 200 * np.mean(np.abs(y_pred - y_test) / (np.abs(y_pred) + np.abs(y_test)))


# In[113]:


####################################### DBN Begins here ###################################################
X, y,X_train, X_test, y_train, y_test= data_transformation(amj_manipulated_data)
scaler = MinMaxScaler()
scaled_features = scaler.fit_transform(X)
dbn_input = Input(shape=(scaled_features.shape[1],))
x = Dense(units=100, activation='relu')(dbn_input)
x = Dense(units=80, activation='relu')(x)
x = Dense(units=60, activation='relu')(x)
dbn_output = Dense(units=20, activation='linear')(x)
dbn_model = Model(inputs=dbn_input, outputs=dbn_output)
dbn_model.compile(optimizer='adam', loss='mean_squared_error')

# Train the DBN model
dbn_model.fit(scaled_features, y, epochs=50, batch_size=32)

dbn_output = dbn_model.predict(scaled_features)
n_samples, n_features = dbn_output.shape
n_timesteps = 1
dbn_output_reshaped = dbn_output.reshape((n_samples, n_timesteps, n_features))
lstm_input = Input(shape=(n_timesteps, n_features))

X_train, X_test, y_train, y_test = train_test_split(dbn_output_reshaped,y, test_size=0.2, random_state=42)
######################################## LSTM begins here ###################################################
x = LSTM(50, activation='relu')(lstm_input)
lstm_output = Dense(1)(x)  # Output layer with one neuron for regression
lstm_model = Model(inputs=lstm_input, outputs=lstm_output)
lstm_model.compile(optimizer='adam', loss='mse')  # Mean Squared Error (MSE) loss for regression
lstm_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=2)
predictions = lstm_model.predict(X_test)

predicted_prices_DBN_LSTM=predictions.flatten()
mse_DBN_LSTM = mean_squared_error(y_test, predicted_prices_DBN_LSTM)
mae_DBN_LSTM = mean_absolute_error(y_test, predicted_prices_DBN_LSTM)
r2_DBN_LSTM = r2_score(y_test, predicted_prices_DBN_LSTM)
msle_DBN_LSTM = mean_squared_log_error(y_test, predicted_prices_DBN_LSTM)
evs_DBN_LSTM = explained_variance_score(y_test, predicted_prices_DBN_LSTM)
smape_DBN_LSTM = smape(y_test, predicted_prices_DBN_LSTM)
huber_DBN_LSTM = huber_loss(y_test, predicted_prices_DBN_LSTM)


# In[114]:


X, y,X_train,X_test,y_train,y_test= data_transformation(amj_manipulated_data)
xgb_model = xgb.XGBRegressor()
xgb_model.fit(X_train, y_train)
predictions_xgb = xgb_model.predict(X_test)


#result_xgb = pd.DataFrame({'Actual Close': y_test, 'Predicted Close': predictions_xgb})

mse_xgb = mean_squared_error(y_test, predictions_xgb)
mae_xgb = mean_absolute_error(y_test, predictions_xgb)
r2_xgb  = r2_score(y_test, predictions_xgb)
msle_xgb = mean_squared_log_error(y_test, predictions_xgb)
evs_xgb = explained_variance_score(y_test, predictions_xgb)
smape_xgb = smape(y_test, predictions_xgb)
huber_xgb = huber_loss(y_test, predictions_xgb)


# In[115]:


X,y,X_train,X_test,y_train,y_test= data_transformation(amj_manipulated_data)
alpha = 3
ridge_model = Ridge(alpha = alpha)

ridge_model.fit(X_train, y_train)
predictions_ridge = ridge_model.predict(X_test)

#result_ridge = pd.DataFrame({'Actual Close': y_test, 'Predicted Close': predictions_ridge})

#result_ridge

mse_ridge   = mean_squared_error(y_test, predictions_ridge)
mae_ridge   = mean_absolute_error(y_test, predictions_ridge)
r2_ridge    = r2_score(y_test, predictions_ridge)
msle_ridge = mean_squared_log_error(y_test, predictions_ridge)
evs_ridge   = explained_variance_score(y_test, predictions_ridge)
smape_ridge  = smape(y_test, predictions_ridge)
huber_ridge  = huber_loss(y_test, predictions_ridge)


# In[116]:


'''
This part of the code plots the graph of all calculated statistics of all model for 
comparision to come up with with best model.
'''
dbn_lstm_values = np.array([mse_DBN_LSTM, mae_DBN_LSTM, r2_DBN_LSTM, msle_DBN_LSTM, evs_DBN_LSTM,smape_DBN_LSTM,huber_DBN_LSTM])
xgb_values = np.array([mse_xgb, mae_xgb, r2_xgb, msle_xgb, evs_xgb,smape_xgb,huber_xgb])
ridge_values = np.array([mse_ridge, mae_ridge, r2_ridge, msle_ridge, evs_ridge,smape_ridge,huber_ridge])

# Combine them into a 2D array
statistical_values = np.vstack((dbn_lstm_values, xgb_values, ridge_values))
dbn_lstm_values = statistical_values[0, :]
xgb_values = statistical_values[1, :]
ridge_values = statistical_values[2, :]

# Define the statistical values
statistical_values = ['MSE', 'MAE', 'R2', 'MSLE', 'EVS', 'SMAPE','HUBER']

# Plotting individual bar graphs for each statistical value
for i in range(len(statistical_values)):
    values = [dbn_lstm_values[i], xgb_values[i], ridge_values[i]]
    
    plt.figure(figsize=(8, 6))
    models = ['DBN_LSTM', 'XGB', 'Ridge']
    bars = plt.bar(models, values, color=['blue', 'red', 'cyan'])
    plt.title(f'{statistical_values[i]} Comparison Across Models')
    plt.xlabel('Models')
    plt.ylabel(statistical_values[i])


    # Adding the values on top of the bars
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, yval, round(yval, 2), va='bottom') # va: vertical alignment

    plt.show()


# In[25]:


def data_transformation_model2(data):
    '''
    This function splits the data for model-2 into test and train part.
    '''
    X = data.drop(data.iloc[:, 5:], axis = 1)
    y = data.iloc[:, :4].copy()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size = 0.2, random_state = 42)
    
    return X, y, X_train, X_test, y_train, y_test,X_scaled


# In[26]:


model2_df = amj_manipulated_data.iloc[:, :5].copy()


# In[27]:


model2_df=model2_df.rename(columns={'Open': 'Prev Open', 'High': 'Prev High', 'Low': 'Prev Low', 'Close': 'Prev Close'})
model2_df = pd.merge(amj_df_stats.iloc[:, :5], model2_df, on = 'Date', how='inner')
model2_df = model2_df.drop(['Adj Close'],axis=1)


# In[28]:


model2_df = model2_df.rename(columns={'Open': 'Curr Open', 'High': 'Curr High', 'Low': 'Curr Low', 'Close': 'Curr Close'})


# In[29]:


model2_df


# In[30]:


def predict_adj_close(adjdbnmodel,adjlstmmodel,scaler_1,temp_input_prep):
    '''
    This function call is a pattern prediction function that predicts the current days Adj Close. 
    The trained dbn and lstm models, the models scaler function, and the data set used to predict 
    are all essential parameters for this function.
    '''
    scaled_new_features = scaler_1.transform(temp_input_prep.drop('Curr Adj Close', axis =1))    
    # Get the output of the DBN model
    dbn_new_output = adjdbnmodel.predict(scaled_new_features)
    
    # Reshape the features for LSTM input
    n_samples, n_features = dbn_new_output.shape
    n_timesteps = 1
    dbn_new_output_reshaped = dbn_new_output.reshape((n_samples, n_timesteps, n_features))
    
    # Make predictions using the LSTM model
    new_predictions = adjlstmmodel.predict(dbn_new_output_reshaped)
    return new_predictions.flatten()


# In[31]:


def predict_OHLC(ohlvdbnmodel,ohlvlstmmodel,scaler_2,temp_input_prep):
    '''
    This function call is a pattern prediction function that predicts the current days Open, High, Low, Close. 
    The trained dbn and lstm models, the models scaler function, and the data set used to predict 
    are all essential parameters for this function.
    '''
    
    scaled_new_features = scaler_2.transform(temp_input_prep)    
    # Get the output of the DBN model
    dbn_new_output = ohlvdbnmodel.predict(scaled_new_features)
    
    # Reshape the features for LSTM input
    n_samples, n_features = dbn_new_output.shape
    n_timesteps = 1
    dbn_new_output_reshaped = dbn_new_output.reshape((n_samples, n_timesteps, n_features))
    
    # Make predictions using the LSTM model
    new_predictions = ohlvlstmmodel.predict(dbn_new_output_reshaped)
    return new_predictions.flatten()


# In[1]:


def train_for_adj(amj_manipulated_data2):
    '''
    This function trains the model-1(DBN+LSTM) to forecast current days adj close based on previous days 
    open, high, low, close, adj CLose, and certain technical indicators such as RSI, SMA, and so on.
    '''
    ####################################### DBN Begins here to predict Adj Close ###################################################
    X, y, *_ = data_transformation(amj_manipulated_data2)
    scaler = MinMaxScaler()
    scaled_features = scaler.fit_transform(X)
    dbn_input = Input(shape=(scaled_features.shape[1],))
    x = Dense(units=100, activation='relu')(dbn_input)
    x = Dense(units=80, activation='relu')(x)
    x = Dense(units=60, activation='relu')(x)
    dbn_output = Dense(units=20, activation='linear')(x)
    dbn_model = Model(inputs=dbn_input, outputs=dbn_output)
    dbn_model.compile(optimizer='adam', loss='mean_squared_error')
    
    # Train the DBN model
    dbn_model.fit(scaled_features, y, epochs=50, batch_size=32)
    
    dbn_output = dbn_model.predict(scaled_features)
    n_samples, n_features = dbn_output.shape
    n_timesteps = 1
    dbn_output_reshaped = dbn_output.reshape((n_samples, n_timesteps, n_features))
    lstm_input = Input(shape=(n_timesteps, n_features))
    
    X_train, X_test, y_train, y_test = train_test_split(dbn_output_reshaped,y, test_size=0.2, random_state=42)
    ######################################## LSTM begins here to predict Adj Close ###################################################
    x = LSTM(50, activation='relu')(lstm_input)
    lstm_output = Dense(1)(x)  # Output layer with one neuron for regression
    lstm_model = Model(inputs=lstm_input, outputs=lstm_output)
    lstm_model.compile(optimizer='adam', loss='mse')  # Mean Squared Error (MSE) loss for regression
    lstm_model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=2)
    mse = lstm_model.evaluate(X_test, y_test, verbose=0)
    print(f'Mean Squared Error on test set: {mse}')
    return dbn_model,lstm_model,scaler    
def train_for_OHLC(model2_df):
    '''
    This function trains model-2(DBN+LSTM) to forecast current days Open, High, Low, and Close using 
    previous days Open, High, Low, and Close, as well as predicted Adj Close from model-1.
    '''
    ####################################### DBN Begins here to predict OHLC #############################
    X2,y2,*_,X2_scaled = data_transformation_model2(model2_df)
    scaler_2 = MinMaxScaler()
    X_scaled_2 = scaler_2.fit_transform(X2)
    # Define and train the DBN model
    dbn_model_2 = Sequential()
    dbn_model_2.add(Dense(units=100, activation='relu', input_dim=X_scaled_2.shape[1]))
    dbn_model_2.add(Dense(units=80, activation='relu'))
    dbn_model_2.add(Dense(units=60, activation='relu'))
    dbn_model_2.add(Dense(units=4, activation='linear'))  # Output layer with 20 neurons
    dbn_model_2.compile(optimizer='adam', loss='mean_squared_error')
    
    # Train the DBN model
    dbn_model_2.fit(X_scaled_2, y2, epochs=50, batch_size=32)
    
    # Get the output of the DBN as the input for LSTM
    dbn_output_2 = dbn_model_2.predict(X_scaled_2)
    
    # Reshape the features for LSTM input (assuming a time series structure)
    n_samples, n_features = dbn_output_2.shape
    n_timesteps=1
    dbn_output_reshaped_2 = dbn_output_2.reshape((n_samples, n_timesteps, n_features))
    
    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(dbn_output_reshaped_2, y2, test_size=0.2, random_state=42)
    
     ######################################## LSTM begins here to predict Adj Close ###################################################
    lstm_model_2 = Sequential()
    lstm_model_2.add(LSTM(50, activation='relu', input_shape=(n_timesteps, n_features)))
    lstm_model_2.add(Dense(4))  # Output layer with one neuron for regression
    lstm_model_2.compile(optimizer='adam', loss='mse')  # Mean Squared Error (MSE) loss for regression
    
    # Train the LSTM model
    lstm_model_2.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=2)
    
    # Evaluate the LSTM model
    mse = lstm_model_2.evaluate(X_test, y_test, verbose=0)
    print(f'Mean Squared Error on test set: {mse}')
    return dbn_model_2,lstm_model_2,scaler_2    


# In[33]:


def get_trading_days(start_date, end_date, calendar_name="XNYS"):
    '''
    This function returns all of the trading days for the year specified..
    '''
    # Get the trading calendar
    trading_calendar = get_calendar(calendar_name)

    # Generate the trading days between start_date and end_date
    trading_days = trading_calendar.valid_days(start_date, end_date)
    trading_days = pd.to_datetime(trading_days.date)

    return trading_days


# In[34]:


'''
In this part of the code following happens:
1. generating trading days
2. Train model using Initiall Historical Dats for day Zero
3. Predict and simulate for next 20 days
4. Merge the simulated values with historical data to retrain the model and predict and simulate for the next 20 days and so on.
'''
major_df = pd.DataFrame()
start_date = "2023-11-01"
end_date = "2024-12-31"
trading_days = get_trading_days(start_date, end_date)
major_df['Date'] = trading_days
major_df['Prev O'] = 0
major_df['Prev H'] = 0
major_df['Prev L'] = 0
major_df['Prev C'] = 0
major_df['Curr O'] = 0
major_df['Curr H'] = 0
major_df['Curr L'] = 0
major_df['Curr C'] = 0
major_df['Sim Adj Close'] = 0


major_df['Prev O'][0] = amj_manipulated_data['Open'][-1]
major_df['Prev H'][0] = amj_manipulated_data['High'][-1]
major_df['Prev L'][0] = amj_manipulated_data['Low'][-1]
major_df['Prev C'][0] = amj_manipulated_data['Close'][-1]
#
for i in range(0,271):   
    a = [[0]*5]
    a[0][0] = major_df['Prev O'][i]
    a[0][1] = major_df['Prev H'][i]
    a[0][2] = major_df['Prev L'][i]
    a[0][3] = major_df['Prev C'][i]
    
    
    
    
    
    if(i==0 or i==25):
        adj_dbn_model,adj_lstm_model,scale = train_for_adj(amj_manipulated_data)
        sim_adj = predict_adj_close(adj_dbn_model,adj_lstm_model,scale,amj_manipulated_data[-1:])
        
        major_df['Sim Adj Close'][i] = sim_adj
        a[0][4] = major_df['Sim Adj Close'][i]
        
        ohlc_dbn_model,ohlc_lstm_model,scale2 = train_for_OHLC(model2_df)
        b = predict_OHLC(ohlc_dbn_model,ohlc_lstm_model,scale2,a)
    
    
    else:
        sim_adj = predict_adj_close(adj_dbn_model,adj_lstm_model,scale,amj_manipulated_data[-1:])
        
        major_df['Sim Adj Close'][i] = sim_adj
        a[0][4] = major_df['Sim Adj Close'][i]
        
        b = predict_OHLC(ohlc_dbn_model,ohlc_lstm_model,scale2,a)
        
        
    
    #major_df['Sim Adj Close'][i] = sim_adj


    
    major_df['Curr O'][i] = b[0]
    major_df['Curr H'][i] = b[1]
    major_df['Curr L'][i] = b[2]
    major_df['Curr C'][i] = b[3]
    
    
    new_row1 = {'Open': major_df['Curr O'][i], 'High': major_df['Curr H'][i],'Low': major_df['Curr L'][i],'Close': major_df['Curr C'][i], 'Adj Close': major_df['Sim Adj Close'][i]}
    new_index1 = major_df['Date'][i]
    amj_df.loc[new_index1] = new_row1
    
    new_row = {'Curr Open': major_df['Curr O'][i], 'Curr High': major_df['Curr H'][i],'Curr Low': major_df['Curr L'][i],'Curr Close': major_df['Curr C'][i], 'Curr Adj Close': major_df['Sim Adj Close'][i],'Prev Open': major_df['Prev O'][i], 'Prev High': major_df['Prev H'][i],'Prev Low': major_df['Prev L'][i],'Prev Close': major_df['Prev C'][i]}
    new_index = major_df['Date'][i]
    model2_df.loc[new_index] = new_row
    
    
    major_df['Prev O'][i+1] = major_df['Curr O'][i]
    major_df['Prev H'][i+1] = major_df['Curr H'][i]
    major_df['Prev L'][i+1] = major_df['Curr L'][i]
    major_df['Prev C'][i+1] = major_df['Curr C'][i]
    manipulated_amjstats_df2 = stats_for_model(amj_df)
    amj_manipulated_data = data_preparation_for_dbn(manipulated_amjstats_df2)
    
 

