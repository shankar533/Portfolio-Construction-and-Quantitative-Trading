# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 18:20:39 2023

@author: vishw
"""

import yfinance as yf
import pandas as pd
import datetime
import cvxpy as cp
import cvxopt
import copy
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from helperfunctions import*

def get_mu(timeseries):
    """
    Calculates annualized mean according to Meucci's proposal for
  the projection of invariants (https://ssrn.com/abstract=1586656).
  Returns the annualized mean of the input
  timeseries: pandas DataFrame containing daily returns
"""
    
    return np.exp(np.log1p(timeseries).mean()*252)-1

def _mu(timeseries):
    """
    Local performance function; equivalent to get_mu.
    Returns the annualized mean of the input
    timeseries: pandas dataframe containing daily returns
    """
    return np.exp(np.log1p(timeseries).mean()*252)-1

def get_cov(timeseries, annualized=True):
    S = timeseries.cov()
    if annualized:
        S = S * 252
    return S

def get_std(timeseries, annualized=True):
    std = timeseries.std()
    if annualized:
        std = std * np.sqrt(252)
    return std

def get_var(timeseries, annualized=True):
    var = timeseries.var()
    if annualized:
        var = var * 252
    return var

def get_hist_VaR(timeseries, alpha=5):
    return -np.percentile(timeseries, alpha)

def get_hist_CVaR(timeseries, alpha=5):
    belowVaR = timeseries <= np.percentile(timeseries, alpha)
    return -timeseries[belowVaR].mean()

def get_weighted_returns(assets, weights):
    portfolio_rets = assets @ weights
    return portfolio_rets

def get_mvp_weights(timeseries):
    w = cp.Variable(len(timeseries.columns))
    ret = w.T @ _mu(timeseries)
    sigma_square = cp.quad_form(w, get_cov(timeseries))
    objective = cp.Minimize(sigma_square)
    constraints = [
        cp.sum(w) == 1,
        w >= 0
    ]
    
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.OSQP,verbose=False,max_iter = 1000)
    w_mvp = w.value
    
    return w_mvp

def get_max_ret_weights(timeseries):
    w_max = np.zeros(len(timeseries.columns))
    w_max[_mu(timeseries).argmax()] = 1

    return w_max

def get_summary(weights, timeseries, pct=True):
    """
    Returns selected summary statistics on the portfolio.
    
    Parameters:
    - weights: vector of (portfolio) weights
    - timeseries: pandas DataFrame containing daily returns
    - pct: Boolean, defaults to True. If True, displays results in percentage format.
    """
    w_opt = weights
    if pct:
        d = [
            ["### Portfolio Summary ###", ""],
            ["", ""],
            ["Number of Assets:", "{:}".format(np.count_nonzero(weights.round(6) + 0.0))],
            ["Expected Annual Return:", "{:.3f}%".format((w_opt.T @ _mu(timeseries)) * 100)],
            ["Annual Volatility:", "{:.3f}%".format(np.sqrt(w_opt.T @ get_cov(timeseries) @ w_opt) * 100)],
            ["Sharpe Ratio:", (w_opt.T @ _mu(timeseries) / np.sqrt(w_opt.T @ get_cov(timeseries) @ w_opt)).round(3)],
            ["Portfolio Leverage:", get_port_leverage(weights).round(3)],
            ["1-Year 95% VaR:", "{:.3f}%".format(100 * np.sqrt(252) * get_hist_VaR(get_weighted_returns(timeseries, weights)))],
            ["1-Year 95% CVaR:", "{:.3f}%".format(100 * np.sqrt(252) * get_hist_CVaR(get_weighted_returns(timeseries, weights)))],
            ["1-Day 95% VaR:", "{:.3f}%".format(100 * get_hist_VaR(get_weighted_returns(timeseries, weights)))],
            ["1-Day 95% CVaR:", "{:.3f}%".format(100 * get_hist_CVaR(get_weighted_returns(timeseries, weights)))],
            ["", ""],
        ]

        for v in d:
            title, value = v
            print("{:<25} {:<30}".format(title, value))

def get_top_weights(number, timeseries, weights):
    """
    Returns n(umber) of the assets with the biggest weights.
    
    Parameters:
    - number: Integer value defining the number of weights to be returned
    - timeseries: pandas DataFrame containing daily returns
    - weights: vector of (portfolio) weights
    """
    for _ in range(number):
        print(timeseries.iloc[:, (-weights).argsort()[_]].name, weights[(-weights).argsort()[_]].round(5))

    
    
def get_bot_weights(number, timeseries, weights):
    """
    Returns n(umber) of the assets with the smallest weights.
    
    Parameters:
    - number: Integer value defining the number of weights to be returned
    - timeseries: pandas DataFrame containing daily returns
    - weights: vector of (portfolio) weights
    """
    number = number - 1
    for _ in range(number + 1):
        print(timeseries.iloc[:, (weights).argsort()[number - _]].name, weights[(weights).argsort()[number - _]].round(5))


def get_port_leverage(weights):
    """
    Calculates leverage measured in excess of 1
    
    Parameters:
    - weights: vector of (portfolio) weights
    """
    return np.abs(weights).sum().round(5) - 1


"""GENERATE RANDOM PORTFOLIOS"""

def gen_weights(n, long_only=True):
    """
    Returns a vector of n weights.
    
    Parameters:
    - n: Number of weights (portfolios).
    - long_only: Boolean, defaults to True. If True, generates weights for long-only portfolios.
    """
    if long_only:
        # rand for only positive values
        r = np.random.rand(n)
        return r / sum(r)
    else:
        # randn for positive and negative
        r = np.random.randn(n)
        return r / sum(r)

def random_portfolio(timeseries):
    """
    Returns mean, standard deviation and asset weights
    for a random portfolio.
    
    Parameters:
    - timeseries: pandas DataFrame containing daily returns
    """
    M = pd.DataFrame(timeseries.mean())  # Return Vector (3x1)
    w = pd.DataFrame(gen_weights(timeseries.shape[1], 0), index=['A', 'B', 'C'])  # Weight Vector (3x1)
    S = pd.DataFrame(timeseries.cov())  # CovMatrix

    mu = w.T @ M
    sigma = np.sqrt(w.T @ S @ w)

    if sigma.iloc[0, 0] > 5:  # cleaning up outliers for plotting
        return random_portfolio(timeseries)
    return mu, sigma, w

def random_portfolio_long(timeseries):
    """
    Returns mean, standard deviation and asset weights
    for a random (long-only) portfolio.
    
    Parameters:
    - timeseries: pandas DataFrame containing daily returns for 3 assets
    """
    M = pd.DataFrame(timeseries.mean())  # Return Vector (3x1)
    w = pd.DataFrame(gen_weights(timeseries.shape[1], 1), index=['A', 'B', 'C'])  # Weight Vector (3x1)
    S = pd.DataFrame(timeseries.cov())  # CovMatrix

    mu = w.T @ M
    sigma = np.sqrt(w.T @ S @ w)

    if sigma.iloc[0, 0] > 5:  # cleaning up outliers for plotting
        return random_portfolio(timeseries)
    return mu, sigma, w

"""PLOTTING RETURNS"""

def plt_returns(returns, weights, benchmark, save=False):
    """
    Plots time-series of returns in 2-dimensional
    plot with dates on the x-axis. Visualizing return variance.
    
    Parameters:
    - returns: pandas DataFrame containing daily returns
    - weights: vector of weights; has to be the same length as the number of assets
    - benchmark: pandas DataFrame containing daily returns of a benchmark
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.plot(get_weighted_returns(returns, weights),
              label='Optimized', alpha=0.5, color="blue")
    plt.plot(benchmark, label='Index', alpha=0.3, color="red")
    ax.legend()
    plt.ylabel('Return')
    ax.legend()
    plt.tight_layout()  # more space for x and y labels
    plt.grid(alpha=0.3)

    if save:
        plt.savefig('/Users/../_vola.pdf', dpi=500, format='pdf')

    plt.show()
    
    
"""PLOTTING CUMULATIVE RETURNS"""

def plt_cum_returns(returns, weights, benchmark, save=False):
    """
    Plots time-series of cumulative returns in a 2-dimensional
    plot with dates on the x-axis.
    
    Parameters:
    - returns: pandas DataFrame containing daily returns
    - weights: vector of weights; has to be the same length as the number of assets
    - benchmark: pandas DataFrame containing daily returns of a benchmark
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plt.plot((returns @ weights).add(1).cumprod(),
              label='Optimized', alpha=0.5, color="blue")
    plt.plot(benchmark.add(1).cumprod(),
              label='Index', alpha=0.3, color="red")

    ax.legend()
    plt.ylabel('Cumulative Return')
    plt.tight_layout()  # more space for x and y labels
    plt.grid(alpha=0.3)

    if save:
        plt.savefig('/Users/../_opt_return.pdf', dpi=500, format='pdf')

    plt.show()


"""PLOT EFFICIENT FRONTIER"""

def plt_frontier(mu_front, sigma_front, sharpe_front, save=False):
    """
    Calculates and plots the efficient frontier.
    
    Parameters:
    - mu_front: array of efficient means
    - sigma_front: array of efficient standard deviations
    - sharpe_front: array of Sharpe ratios
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)

    plt.plot(sigma_front, mu_front, color='steelblue',
              linewidth=2, alpha=0.5, label='Efficient frontier')  # Plot frontier
    plt.plot(sigma_front[np.argmax(sharpe_front)],
              mu_front[np.argmax(sharpe_front)], marker='*',
              color='steelblue', label="Maximum Sharpe portfolio",
              markersize=12)  # Highlight max Sharpe portfolio

    v = [.1, 1, 2, 3, 5, 10, 20, 30, 50]
    # Levels of risk aversion to be highlighted on the frontier

    for _ in range(len(v)):
        plt.plot(sigma_front[gamma_front.index(v[_])],
                  mu_front[gamma_front.index(v[_])], marker='o', color='steelblue')
        ax.annotate(r"$\gamma = \%.2f$" % (v[_]),
                    xy=(sigma_front[gamma_front.index(v[_])] + .002,
                        mu_front[gamma_front.index(v[_])] - 0.004))
        # Annotate gamma value

    ax.legend(loc=4)
    plt.grid(alpha=0.3)
    plt.xlabel('Standard Deviation (Volatility)')
    plt.ylabel('Expected Annual Return')

    plt.tight_layout()
    if save:
        plt.savefig('/Users/../_frontier.pdf', dpi=500, format='pdf')
    plt.show()


"""EFFICIENT FRONTIER WITH SCATTER PLOT"""

def plt_frontier_scatter(mu_front, sigma_front, sharpe_front, assets, save=False):
    """
    Calculates and plots the efficient frontier relative
    to all assets of the portfolio.

    Parameters:
    - mu_front: array of efficient means
    - sigma_front: array of efficient standard deviations
    - sharpe_front: array of Sharpe ratios
    - assets: pandas DataFrame containing daily returns
    - save: Boolean, defaults to False. If True, saves the plot as a PDF.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111)

    plt.plot(sigma_front, mu_front, color='steelblue',
              linewidth=2, alpha=0.5, label='Efficient frontier')
    # Plot frontier
    plt.plot(sigma_front[np.argmax(sharpe_front)],
              mu_front[np.argmax(sharpe_front)], marker='*',
              color='steelblue', label="Maximum Sharpe portfolio",
              markersize=10)  # Highlight max Sharpe portfolio
    plt.scatter(get_std(assets), get_mu(assets), s=8, label='Assets')
    # Connect the point to the x-axis and y-axis
    x_intersect = sigma_front[np.argmax(sharpe_front)]
    y_intersect = mu_front[np.argmax(sharpe_front)]
    plt.axhline(y=mu_front[np.argmax(sharpe_front)], color='red', linestyle='--', linewidth=1)
    plt.axvline(x=sigma_front[np.argmax(sharpe_front)], color='red', linestyle='--', linewidth=1)
    
    plt.text(x_intersect, 0, f'{x_intersect:.2f}', color='red', ha='center', va='bottom')
    plt.text(0, y_intersect, f'{y_intersect:.2f}', color='red', ha='right', va='center')

    ax.legend(loc=3)
    ax.legend(loc=3)
    plt.grid(alpha=0.3)
    plt.xlabel('Standard Deviation (Volatility)')
    plt.ylabel('Expected Annual Return')

    plt.tight_layout()

    if save:
        plt.savefig('/Users/../_scatter_front.pdf', dpi=500, format='pdf')
    plt.show()


"""PLOTTING CORRELATION MATRIX"""

def plot_corr(timeseries):
    """
    Plot the correlation matrix of log returns.

    Parameters:
    - timeseries: Pandas DataFrame with log returns for multiple stocks.
    """
    # Calculate the correlation matrix
    corr_matrix = timeseries.corr()

    # Set up the matplotlib figure
    plt.figure(figsize=(10, 8))

    # Create a seaborn heatmap with a color gradient
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f', linewidths=.5)

    # Set plot title
    plt.title('Correlation Matrix of Daily Log Returns')

    # Show the plot
    plt.show()
    
    
"""PLOT MAXIMUM DRAWDOWN"""

def maximum_drawdown(timeseries, plot=True):
    """
    Calculates and plots the Maximum Drawdown (MDD) over a given period.

    Parameters:
    - timeseries: pandas DataFrame containing daily returns
    - plot: Boolean, defaults to False. If True, plots the drawdown.

    Returns:
    - None
    """
    if plot:
        plt.plot(np.exp((w.value @ np.log(timeseries + 1).T).cumsum()))
    prev_peak = np.exp((w.value @ np.log(timeseries + 1).T).cumsum()).cummax()
    if plot:
        plt.plot(prev_peak)
    drawdown = (np.exp((w.value @ np.log(timeseries + 1).T).cumsum()) - prev_peak) / prev_peak
    if plot:
        plt.plot(drawdown)
    print("Maximum Drawdown: {:.3f}%".format(drawdown.min() * 100),
          "on", drawdown.idxmin().strftime('%d/%m/%Y'))

    return None



# List of Dow Jones tickers
dow_tickers = [
    "MMM", "AXP", "AAPL", "BA", "CAT", "CVX", "CSCO", "KO", 
    "GS", "HD", "HON", "IBM", "INTC", "JNJ", "JPM", "MCD", "MRK", "MSFT",
    "NKE", "PG", "RTX", "TRV", "UNH", "VZ", "V", "WMT", "DIS", "CRM"
]

# Set the date range for historical data
end_date = datetime.datetime(2023, 12, 1)
start_date = end_date - datetime.timedelta(days=5 * 365)  # 5 years

# Download historical data and store in a DataFrame
historical_data = {}
for ticker in dow_tickers:
    try:
        data = yf.download(ticker, start=start_date, end=end_date)
        historical_data[ticker] = np.log1p(data['Adj Close'].pct_change())
        print(f"Downloaded data for {ticker}")
    except Exception as e:
        print(f"Error downloading data for {ticker}: {e}")

# Create a DataFrame for assets log returns
df_assets = pd.DataFrame(historical_data)

# Download historical data for SPY
spy_data = yf.download("SPY", start=start_date, end=end_date)

# Extract the log returns for SPY
df_index = np.log1p(spy_data['Adj Close'].pct_change()).to_frame()

# Drop NaN values from df_assets and df_index
df_assets = df_assets.dropna()
df_index = df_index.dropna()

# Display the first few rows of the cleaned DataFrames
print(df_assets.head())
print(df_index.head())




has_na = df_assets.isna().any().any()

# Print the result
if has_na:
    print("The DataFrame has NaN values.")
    # To get the count of NaN values in each column, you can use df.isna().sum()
    print("Number of NaN values in each column:")
    print(df_assets.isna().sum())
else:
    print("The DataFrame does not have any NaN values.")
    
rows_with_nan = df_assets[df_assets.isna().any(axis=1)]

# Print the result
if not rows_with_nan.empty:
    print("Rows with NaN values:")
    print(rows_with_nan)
else:
    print("No rows have NaN values.")
    
index_has_na = df_index.isna().any().any()

# Print the result
if index_has_na:
    print("The DataFrame has NaN values.")
    # To get the count of NaN values in each column, you can use df.isna().sum()
    print("Number of NaN values in each column:")
    print(df_index.isna().sum())
else:
    print("The DataFrame does not have any NaN values.")
    
index_rows_with_nan = df_index[df_index.isna().any(axis=1)]

# Print the result
if not index_rows_with_nan.empty:
    print("Rows with NaN values:")
    print(rows_with_nan)
else:
    print("No rows have NaN values.")
    
    
"""RISK AVERSION PROBLEM"""  
    
#Risk aversion optimization#   
w = cp.Variable(len(df_assets.columns))
ret = w.T @ get_mu(df_assets)
sigma_square = cp.quad_form(w, get_cov(df_assets))
gamma = cp.Parameter(nonneg=True)  # cvxpy parameter; modified later
gamma.value = 1.034
objective = cp.Maximize(ret - (gamma * sigma_square))
constraints = [
    cp.sum(w) == 1,
    cp.norm(w, 1) <= 2
    
]
prob = cp.Problem(objective, constraints)
prob.solve(solver=cp.OSQP,verbose=True, max_iter = 1000)
print("Optimization Status:", prob.status)
get_summary_with_weights(w.value,df_assets,dow_tickers)



"""EFFICIENT FRONTIER"""

# Calculates efficient frontier from any optimization problem.
gamma.value = 0
w_opt = np.ones(len(df_assets.columns))
mu_front = []
sigma_front = []
sharpe_front = []
gamma_front = []
weight_front = pd.DataFrame()

# Iterate as long as variance is more than 5*10^-4 away from MVP
while (np.sqrt((w_opt.T @ get_cov(df_assets) @ w_opt)) -
        np.sqrt((get_mvp_weights(df_assets).T @ get_cov(df_assets)
                @ get_mvp_weights(df_assets)))) > 0.0005:
    prob.solve(solver=cp.OSQP,verbose= False, max_iter = 1000)  # cvxpy problem defined outside
    w_opt = w.value
    gamma_front.append(round(gamma.value, 1))  # save current gamma value
    mu_front.append(w.value.T @ get_mu(df_assets))  # save mu for current gamma value
    sigma_front.append(np.sqrt(w.value.T @ get_cov(df_assets) @ w.value))  # save sigma for current gamma value
    sharpe_front.append((w_opt.T @ _mu(df_assets) / np.sqrt(w_opt.T @ get_cov(df_assets) @ w_opt)).round(3))
    weight_front = pd.concat([weight_front,
                              pd.DataFrame(w_opt.reshape((len(w_opt), 1)),
                                          columns=[round(gamma.value, 1)])],
                            axis=1)  # save weights for current gamma value
    gamma.value += 0.1
    
    
    
plt_returns(df_assets, w.value, df_index)
plt_cum_returns(df_assets, w.value, df_index)
plot_corr(df_assets)
plt_frontier_scatter(mu_front, sigma_front, sharpe_front, df_assets)
    
