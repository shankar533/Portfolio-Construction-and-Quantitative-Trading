# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 19:34:47 2023

@author: vishw
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Dec  1 18:20:39 2023

@author: vishw
"""

import yfinance as yf
import pandas as pd
import datetime
import cvxpy as cp
import numpy as np
import copy
import matplotlib.pyplot as plt
import seaborn as sns
from helperfunctions import*
import os







# List of Dow Jones tickers
dow_tickers = [
    "MMM", "AXP", "AAPL", "BA", "CAT", "CVX", "CSCO", "KO", 
    "GS", "HD", "HON", "IBM", "INTC", "JNJ", "JPM", "MCD", "MRK", "MSFT",
    "NKE", "PG", "RTX", "TRV", "UNH", "VZ", "V", "WMT", "DIS", "CRM"
]




# Set the date range for historical data
end_date = datetime.datetime(2022, 12, 31)
start_date = end_date - datetime.timedelta(days=5 * 365)  # 5 years

# Download historical data and store in a DataFrame
historical_data = {}
for ticker in dow_tickers:
    try:
        data = yf.download(ticker, start=start_date, end=end_date)
        historical_data[ticker] = np.log1p(data['Adj Close'].ffill().pct_change())
        print(f"Downloaded data for {ticker}")
    except Exception as e:
        print(f"Error downloading data for {ticker}: {e}")

# Create a DataFrame for assets log returns
df_assets = pd.DataFrame(historical_data)

# Download historical data for SPY
spy_data = yf.download("SPY", start=start_date, end=end_date)

# Extract the log returns for SPY
df_index = np.log1p(spy_data['Adj Close'].pct_change()).to_frame()

# Drop NaN values from df_assets and df_index
df_assets = df_assets.dropna()
df_index = df_index.dropna()

# Display the first few rows of the cleaned DataFrames
print(df_assets.head())
print(df_index.head())




has_na = df_assets.isna().any().any()

# Print the result
if has_na:
    print("The DataFrame has NaN values.")
    # To get the count of NaN values in each column, you can use df.isna().sum()
    print("Number of NaN values in each column:")
    print(df_assets.isna().sum())
else:
    print("The DataFrame does not have any NaN values.")
    
rows_with_nan = df_assets[df_assets.isna().any(axis=1)]

# Print the result
if not rows_with_nan.empty:
    print("Rows with NaN values:")
    print(rows_with_nan)
else:
    print("No rows have NaN values.")
    
index_has_na = df_index.isna().any().any()

# Print the result
if index_has_na:
    print("The DataFrame has NaN values.")
    # To get the count of NaN values in each column, you can use df.isna().sum()
    print("Number of NaN values in each column:")
    print(df_index.isna().sum())
else:
    print("The DataFrame does not have any NaN values.")
    
index_rows_with_nan = df_index[df_index.isna().any(axis=1)]

# Print the result
if not index_rows_with_nan.empty:
    print("Rows with NaN values:")
    print(rows_with_nan)
else:
    print("No rows have NaN values.")
    

w_optP = {}
start_dict = {}
end_dict = {}
end_value = {}

df_combined = pd.DataFrame()

d_start = df_assets.index[0]+pd.offsets.YearBegin(-1)
#Set first Date of dataframe as start of the opt period
start_dict[0] = d_start
d_end = d_start+pd.offsets.YearEnd(0)
#Set end of opt period 1 year from start
end_dict[0] = d_start
df_assetsP = df_assets.loc[d_start:d_end]
df_indexP = df_index.loc[d_start:d_end]
#Create dataframe for current period



gamma = cp.Parameter(nonneg=True)  # cvxpy parameter; modified later

# Minimize portfolio Sharpe for given return (ret)
z = cp.Variable(len(df_assetsP.columns),) #transformed variable
k = cp.Variable() #scalar (variable)
ret = z.T@get_mu(df_assetsP)
sigma_square = cp.quad_form(z, get_cov(df_assetsP))
objective = cp.Minimize(sigma_square)
constraints = [
    ret == 1, #adjustable return target constraint
    cp.sum(z) == k,
    z>=0,
    k >= 0
    
]

prob = cp.Problem(objective, constraints)
prob.solve(solver=cp.OSQP,verbose = False)
w = (z.value / k.value)
get_summary_with_weights(w, df_assetsP, dow_tickers)

w_optP[0] = copy.copy(w)
i = 0


#Iterations over all 1-year periods of the given timeseries
while i < len(pd.date_range(df_assets.index[0],
df_assets.index[-1], freq='1Y')):
    d_start = df_assets.index[0]+pd.offsets.YearBegin(i+1)
    start_dict[i+1] = d_start
    d_end = d_start+pd.offsets.YearEnd(0)
    end_dict[i+1] = d_end
    df_assetsP = df_assets.loc[d_start:d_end]
    df_indexP = df_index.loc[d_start:d_end]
    
    z = cp.Variable(len(df_assetsP.columns),) #transformed variable
    k = cp.Variable() #scalar (variable)
    ret = z.T@get_mu(df_assetsP)
    sigma_square = cp.quad_form(z, get_cov(df_assetsP))
    objective = cp.Minimize(sigma_square)
    constraints = [
        ret == 1, #adjustable return target constraint
        cp.sum(z) == k,
        z>=0,
        k >= 0
        
    ]

    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.OSQP,verbose = False)
    w = (z.value / k.value)
    get_summary_with_weights(w, df_assetsP, dow_tickers)
    w_optP[i+1] = copy.copy(w)
    _temp_rets = (df_assets.loc[start_dict[i+1]:end_dict[i+1]])@w_optP[i]
    #Calculate weighted returns for current period
    df_temp_rets = pd.DataFrame(_temp_rets)
    df_combined = df_combined.append(df_temp_rets)
    #Append current weighted returns to DataFrame with previous returns
    i += 1





# """EFFICIENT FRONTIER"""

# # Calculates efficient frontier from any optimization problem.
# gamma.value = 0
# w_opt = np.ones(len(df_assets.columns))
# mu_front = []
# sigma_front = []
# sharpe_front = []
# gamma_front = []
# weight_front = pd.DataFrame()

# # Iterate as long as variance is more than 5*10^-4 away from MVP
# while (np.sqrt((w_opt.T @ get_cov(df_assets) @ w_opt)) -
#         np.sqrt((get_mvp_weights(df_assets).T @ get_cov(df_assets)
#                 @ get_mvp_weights(df_assets)))) > 0.0005:
#     prob.solve(solver=cp.OSQP,verbose= False, max_iter = 1000)  # cvxpy problem defined outside
#     w_opt = w.value
#     gamma_front.append(round(gamma.value, 1))  # save current gamma value
#     mu_front.append(w.value.T @ get_mu(df_assets))  # save mu for current gamma value
#     sigma_front.append(np.sqrt(w.value.T @ get_cov(df_assets) @ w.value))  # save sigma for current gamma value
#     sharpe_front.append((w_opt.T @ _mu(df_assets) / np.sqrt(w_opt.T @ get_cov(df_assets) @ w_opt)).round(3))
#     weight_front = pd.concat([weight_front,
#                               pd.DataFrame(w_opt.reshape((len(w_opt), 1)),
#                                           columns=[round(gamma.value, 1)])],
#                             axis=1)  # save weights for current gamma value
#     gamma.value += 0.1
    
    
    
# plt_returns(df_assets, w.value, df_index)
# plt_cum_returns(df_assets, w.value, df_index)
# plot_corr(df_assets)
# plt_frontier_scatter(mu_front, sigma_front, sharpe_front, df_assets)
    
